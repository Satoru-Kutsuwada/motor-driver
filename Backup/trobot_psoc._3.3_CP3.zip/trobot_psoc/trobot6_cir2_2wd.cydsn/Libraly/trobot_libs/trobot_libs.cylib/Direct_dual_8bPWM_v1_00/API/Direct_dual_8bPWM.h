/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define `$INSTANCE_NAME`_Period_Reg (*(reg8 *) `$INSTANCE_NAME`_cntr8_u0__D0_REG)
#define `$INSTANCE_NAME`_Compare1_Reg (*(reg8 *) `$INSTANCE_NAME`_cntr8_u0__D1_REG)
#define `$INSTANCE_NAME`_Compare2_Reg (*(reg8 *) `$INSTANCE_NAME`_cntr8_u0__A1_REG)

/* [] END OF FILE */
