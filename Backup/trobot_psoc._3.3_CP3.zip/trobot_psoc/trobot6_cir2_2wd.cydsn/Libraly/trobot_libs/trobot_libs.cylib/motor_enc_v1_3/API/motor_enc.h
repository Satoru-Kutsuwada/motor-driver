/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
//#define `$INSTANCE_NAME`_enc_value (*(reg16 *)`$INSTANCE_NAME`_motor_enc_u0__a1_REG)

//[] END OF FILE
