/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define Direct_dual_8bPWM_1_Period_Reg (*(reg8 *) Direct_dual_8bPWM_1_cntr8_u0__D0_REG)
#define Direct_dual_8bPWM_1_Compare1_Reg (*(reg8 *) Direct_dual_8bPWM_1_cntr8_u0__D1_REG)
#define Direct_dual_8bPWM_1_Compare2_Reg (*(reg8 *) Direct_dual_8bPWM_1_cntr8_u0__A1_REG)

/* [] END OF FILE */
